const mongoose = require('mongoose');
const CONNECTION_STRING = 'mongodb://127.0.0.1:27017/name';

module.exports = async (app) => {
  try {
    mongoose.set('strictQuery', false);
    await mongoose.connect(CONNECTION_STRING, {
      useUnifiedTopology: true,
      useNewUrlParser: true
    });
    console.log('Db connected');
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
};